import { Injectable } from '@angular/core';
import { Body } from '@angular/http/src/body';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Http } from '@angular/http';

@Injectable({ providedIn: 'root' })
export class simpleService {
  constructor(private http: HttpClient) {}

  setProducts(body: any) {
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Accept', 'application/json');
    let result = this.http.post('https://dummyjson.com/products', body, {
      headers: headers,
    });
    return result;
  }

  getProducts() {
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Accept', 'application/json');

    let url = 'https://dummyjson.com/products';
    let result = this.http.get(url, { headers: headers });
    return result;
  }
}
