import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { simpleService } from './simpleService.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  product: FormGroup;
  viewValue: any;
  constructor(
    private formbuilder: FormBuilder,
    private service: simpleService
  ) {
    this.product = new FormGroup({
      id: new FormControl(''),
      title: new FormControl(''),
      description: new FormControl(''),
      price: new FormControl(''),
    });
  }

  ngOnInit() {
    this.getProducts();
  }

  getProducts() {
    this.service.getProducts().subscribe((response) => {
      this.viewValue = response;
      console.log(this.viewValue);
    });
  }

  submit() {
    let body = this.product.value;
    this.service.setProducts(body).subscribe((response) => {
      console.log(response);
      this.product.reset();
    });
  }
}
